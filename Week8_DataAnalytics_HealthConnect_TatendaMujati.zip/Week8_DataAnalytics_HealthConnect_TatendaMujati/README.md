# HealthConnect: Final Analytics & Decision Support (Data Analytics track)

**AnalystLab Africa Experience Lab | Week 8 | Tatenda Mujati**

How can HealthConnect Clinic use data and AI to reduce missed appointments and improve the patient support experience? This repository holds the Data Analytics contribution, evolved from Week 5 to Week 8.

## Result in brief
- 27 source tables cleaned and loaded into PostgreSQL; 89 SQL queries; Python cleaning pipeline; six-page Power BI dashboard.
- Every KPI recomputed independently and matched to SQL. Headline: billed RWF 9.31bn, 90.1% collected, RWF 920m outstanding; 42,036 claims (49.98% approved, 21,028 pending, RWF 2.44bn); satisfaction 2.99/5.
- Validated across 19 segment checks: collection, claim approval and satisfaction are the same everywhere, so effort belongs on process (claims, collections, service experience), not facility ranking.
- Attendance / no-show: not measurable in the files analysed (no attendance field, no valid proxy). Data Science's model is the predictive component (reported accuracy 62.4% to 64.8%, ROC-AUC 0.677 to 0.687, Brier 0.2246; driven by lead time, past no-show and distance). My checks on the Specialist Consultation error: class imbalance ruled out, small sample suggestive, structure open.

## Status (stated plainly)
| Item | Status |
|---|---|
| Final KPIs, validated findings, recommendations, executive summary, slides, video script | Complete |
| Power BI dashboard | Week 6 build; v2 refinements prepared (DAX + checklist), **not yet applied in Desktop** |
| Attendance / no-show pattern analysis | **Not done on a dataset**: needs the appointment file held by Data Science (per-type results used as reported) |
| Cross-track | Data Science exchange complete on 12 and 17 Nov (four screenshots and transcripts included); other tracks not yet recorded |

## Repository map
`Reports/` final report, executive summary, workbook | `Presentation/` PowerPoint slides (.pptx) and PDF copy | `Video/` script | `Data/Final_KPIs.csv` | `Figures/` | `Dashboard/` .pbix, DAX v2, checklist | `Cross_Track/` records and evidence | `Evidence/` Week 7 test register | `Python/` scripts.

## Reproduce
`pip install pandas numpy scipy matplotlib reportlab xlsxwriter python-pptx pillow` then `bash Python/run_all.sh <Week 6 package root> <Week 7 evidence dir>`. Week 6 package: SQL database, cleaning pipeline and the 27 source files (not duplicated here).

## Limitations
Facility, department and time views use 8.3% of appointments; model results are Data Science's and not recomputed; results are very uniform across segments (possible synthetic data); no slot, bed-status or capacity data.
