#!/usr/bin/env bash
# Rebuilds KPIs, figures, report, executive summary, workbook and slides.
# Usage: bash Python/run_all.sh <Week 6 package root> [slides to PDF: needs LibreOffice 'soffice']
set -euo pipefail
W6="${1:?path to the Week 6 package root}"; H="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$H/Figures" "$H/Data" "$H/Reports"
python3 -W ignore "$H/Python/week8_kpis.py" "$W6" "$H/Data/_kpi"
mkdir -p "$H/Evidence/Week8_CrossTrack"
python3 -W ignore "$H/Python/week8_crosstrack.py" "$H/Evidence/Week8_CrossTrack"
python3 -W ignore "$H/Python/week8_figures.py" "$H/Data/_kpi" "$H/Evidence/Week7" "$H/Figures" "$W6"
python3 -W ignore "$H/Python/week8_report.py" "$H/Data/_kpi" "$H/Figures" "$H/Reports" "$H/Evidence/Week7" "$H/Evidence/Screenshots"
python3 -W ignore "$H/Python/week8_assets.py" "$H/Data/_kpi" "$H/Figures" "$H"
command -v soffice >/dev/null && (cd "$H/Presentation" && soffice --headless --convert-to pdf Week8_Analytics_Presentation.pptx >/dev/null 2>&1) || true
