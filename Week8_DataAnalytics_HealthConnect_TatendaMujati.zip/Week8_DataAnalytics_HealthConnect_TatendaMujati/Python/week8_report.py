#!/usr/bin/env python3
"""Builds the Week 8 final analytics report and one-page executive summary.
Usage: week8_report.py <kpi_dir> <figs_dir> <pdf_dir> <week7_evidence_dir> <screenshots_dir>"""
import sys, json, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PI

KD, FG, PD, W7, SH = sys.argv[1:6]
os.makedirs(PD, exist_ok=True)
k = json.load(open(f'{KD}/final_kpis.json'))
D = '/usr/share/fonts/truetype/dejavu/'
for n, f in [('DV', 'DejaVuSans.ttf'), ('DVB', 'DejaVuSans-Bold.ttf'), ('DVI', 'DejaVuSans-Oblique.ttf')]:
    pdfmetrics.registerFont(TTFont(n, D + f))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DVB', italic='DVI', boldItalic='DVB')
INK, BLUE, GREY, LIGHT = colors.HexColor('#1f2933'), colors.HexColor('#2a6fb0'), colors.HexColor('#616e7c'), colors.HexColor('#eef2f6')
S = dict(
    body=ParagraphStyle('b', fontName='DV', fontSize=8.8, leading=12.6, textColor=INK, spaceAfter=4),
    h1=ParagraphStyle('h1', fontName='DVB', fontSize=13, leading=16, textColor=BLUE, spaceBefore=8, spaceAfter=5),
    h2=ParagraphStyle('h2', fontName='DVB', fontSize=10, leading=13, textColor=INK, spaceBefore=6, spaceAfter=3),
    title=ParagraphStyle('t', fontName='DVB', fontSize=20, leading=25, textColor=INK),
    sub=ParagraphStyle('s', fontName='DV', fontSize=10, leading=14, textColor=GREY),
    cell=ParagraphStyle('c', fontName='DV', fontSize=7.6, leading=9.8, textColor=INK),
    cellb=ParagraphStyle('cb', fontName='DVB', fontSize=7.6, leading=9.8, textColor=colors.white),
    small=ParagraphStyle('sm', fontName='DVI', fontSize=7.6, leading=9.8, textColor=GREY, spaceAfter=4),
    bullet=ParagraphStyle('bl', fontName='DV', fontSize=8.8, leading=12.4, textColor=INK, leftIndent=11, bulletIndent=1, spaceAfter=2),
    box=ParagraphStyle('bx', fontName='DV', fontSize=9.2, leading=13.4, textColor=INK, backColor=LIGHT, borderPadding=(6, 7, 6, 7), spaceBefore=3, spaceAfter=8),
)
P = lambda t, s='body': Paragraph(t, S[s])
def B(items): return [Paragraph(t, S['bullet'], bulletText='•') for t in items]
def tbl(rows, widths, head=True):
    data = [[Paragraph(str(c), S['cellb'] if (head and i == 0) else S['cell']) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * mm for w in widths], repeatRows=1 if head else 0)
    st = [('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LINEBELOW', (0, 0), (-1, -1), .25, colors.HexColor('#cbd2d9')), ('LEFTPADDING', (0, 0), (-1, -1), 3),
          ('RIGHTPADDING', (0, 0), (-1, -1), 3), ('TOPPADDING', (0, 0), (-1, -1), 2.2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2.2)]
    if head: st.append(('BACKGROUND', (0, 0), (-1, 0), BLUE))
    for i in range(2, len(rows), 2): st.append(('BACKGROUND', (0, i), (-1, i), LIGHT))
    t.setStyle(TableStyle(st)); return t
def fig(name, w=165):
    im = PI.open(f'{FG}/{name}.png'); return Image(f'{FG}/{name}.png', width=w * mm, height=w * im.size[1] / im.size[0] * mm)
def footer(c, d):
    c.saveState(); c.setFont('DV', 7); c.setFillColor(GREY)
    c.drawString(20 * mm, 10 * mm, 'HealthConnect | Week 8 Final Analytics & Decision Support | Tatenda Mujati | AnalystLab Africa')
    c.drawRightString(190 * mm, 10 * mm, f'Page {d.page}'); c.restoreState()
def build(path, story, title):
    SimpleDocTemplate(path, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=16 * mm, bottomMargin=16 * mm, title=title,
                      author='Tatenda Mujati').build(story, onFirstPage=footer, onLaterPages=footer)
bn = lambda v: f'RWF {v/1e9:.2f}bn'
rwf = lambda v: f'RWF {v:,.0f}'

EXEC = (f'<b>Answer to the project question, from the analytics side.</b> HealthConnect cannot yet measure missed appointments from the data I analysed: the {k["appointment_ids"]:,} appointment records in my files carry no attendance field, '
        f'and only {k["detailed_pct"]}% have facility, department or date detail. Data Science’s model (accuracy 62.4% → 64.8%, ROC-AUC 0.677 → 0.687, as reported by them) is the predictive component; Data Science confirms it is driven by booking lead time, past no-show rate and distance, not by the segment variables I found uninformative. Its discrimination is modest, and its error is highest for Specialist Consultation (42.8%), where my checks rule out class imbalance and leave small sample size and booking structure as the open explanations. '
        f'What my validated analytics do show is where administrative effort is being lost: <b>{bn(k["pending_value"])} sits in {k["claims_pending"]:,} pending insurance claims</b>, '
        f'<b>{bn(k["bills_no_claim_value"])} in {k["bills_no_claim"]:,} bills has no claim at all</b>, and {rwf(k["outstanding"])} is unpaid on {k["bills_with_balance"]:,} bills. '
        f'Patient satisfaction is {k["avg_rating"]}/5 with {k["poor_pct"]:.0f}% poor ratings <b>in every facility, department and month</b>, so this is a network-wide service problem, not a facility ranking problem.')

# =============================================================== MAIN REPORT
st = [Spacer(1, 6 * mm), P('HealthConnect Final Analytics &amp; Decision Support Report', 'title'), Spacer(1, 2 * mm),
      P('AnalystLab Africa Experience Lab | Week 8 | Data Analytics track<br/>Tatenda Mujati (mujatitatenda192@gmail.com) | November 2026', 'sub'), Spacer(1, 4 * mm),
      P('1. Executive summary', 'h1'), P(EXEC, 'box'),
      P('<b>Five validated findings</b> (each tested in Week 7 across every available segment):'),
      *B([f'Collection is {k["collection_pct"]}% of billed value everywhere; {rwf(k["outstanding"])} outstanding.',
          f'Insurance claims are the biggest cash lever: approval is about {k["approval_pct"]:.0f}% for every insurer and bill size; {k["claims_pending"]:,} claims pending.',
          f'Satisfaction is {k["avg_rating"]}/5 with no facility, department, visit type or month different from the network.',
          'The facility ranking in the Week 6 dashboard is statistical noise and has been withdrawn.',
          'No attendance or no-show rate can be calculated from my files; the data needed to answer the project question is missing, not the analysis.']),
      P('<b>Recommendations in priority order:</b> (1) record attendance status and appointment detail for every appointment; (2) fix the claims workflow; (3) target collections by balance size; '
        '(4) run a network-wide service-experience programme; (5) pilot model-prioritised reminders under Data Science’s documented limits. Section 8 gives evidence, owners and success measures.'),
      P('<b>What is not finished:</b> the attendance / no-show pattern analysis (needs Data Science’s appointment dataset), the Power BI v2 refinements (need Desktop), and the structural check on Specialist Consultation (needs Data Science’s appointment file). Section 11 lists each.', 'body')]

# 2 transition
st += [P('2. Week 7 → Week 8 transition', 'h1'),
       tbl([['Item', 'Answer'],
            ['1. Main Week 7 output', 'Analytics Testing &amp; Refinement Report (13 pages), 54-test register, 24 refinement measures (DAX v2), cross-track record with Data Science.'],
            ['2. Most important testing result', 'All 14 headline KPIs recompute exactly; every key finding holds in all 19 segmentations tested.'],
            ['3. Major issue discovered', 'Slicers silently switch dashboard cards from 60,000 to the 5,000-appointment sample (revenue RWF 9.31bn → 0.77bn); no attendance data in my files; the tracks use different appointment datasets.'],
            ['4. Refined or improved', 'Scope-aware measures, tiers instead of rankings, trend and caveat wording, cross-track hypotheses for the Specialist Consultation error.'],
            ['5. Now considered ready', 'The final KPI set and the validated findings (this report).'],
            ['6. Still to integrate', 'Power BI v2 changes (Desktop); attendance analysis on Data Science’s dataset (their reply of 17 Nov confirms the model uses no billing, payment or claims fields, so it is not affected by my data cautions); the Specialist structure check.'],
            ['7. Tracks in final integration', 'Data Science (final exchange completed 17 Nov 2026, evidenced). Project Management, GenAI and ML Engineering: outputs prepared (Section 10), no exchange recorded yet.'],
            ['8. To demonstrate', 'Final KPIs, five validated findings, prioritised recommendations, how analytics supports the model, and exactly what is not yet answerable.']],
           [46, 124])]

# readiness
st += [P('3. Final integration readiness', 'h1'),
       tbl([['Requirement', 'Response'],
            ['What is my final component?', 'The Final Analytics &amp; Decision Support Package: final KPIs, validated findings, visualisations, recommendations, limitations, executive summary, slides, plus the Power BI dashboard.'],
            ['What problem does it address?', 'Tells HealthConnect where administrative and operational effort is lost, what the data can and cannot say about missed appointments, and which decisions the evidence supports.'],
            ['Current status', 'Report, KPIs, workbook, slides, video script: complete. Power BI v2 and attendance analysis: <b>not complete</b> (see Section 11).'],
            ['What did I improve during Week 7?', 'Found and fixed the slicer scope problem; withdrew the facility ranking; added tests, caveats and tiers; connected my findings to Data Science.'],
            ['Which tracks does it depend on?', 'Data Science (appointment dataset with no-show outcome; model results). Project Management (agreed headline appointment count, issue log).'],
            ['Which tracks depend on my output?', 'Data Science (validated findings, data-quality warnings); Project Management (insights and issues); GenAI (candidate administrative topics).'],
            ['What output will I provide?', 'Final KPI table, validated findings, handoff note, recommendations, executive summary.'],
            ['What output do I need from another track?', 'Data Science: per-type no-show rate, case counts and the appointment file. Project Management: one agreed appointment-count definition.'],
            ['What evidence demonstrates readiness?', 'Week 7 test register (54 tests), KPI cross-check against SQL (11 exact matches, Section 4), Slack exchange with Data Science (Appendix C).'],
            ['What limitations remain?', 'Section 11.']],
           [50, 120])]

# 4 KPIs
rows = [['KPI', 'Final value', 'Base / definition', 'Validation'],
        ['Registered patients', f'{k["patients"]:,}', 'All patients', 'A01'],
        ['Average age', f'{k["avg_age"]}', 'All patients', 'A02'],
        ['Male share / chronic condition / aged over 65', f'{k["male_pct"]}% / {k["chronic_pct"]}% / {k["age_over65_pct"]}%', f'Asthma, hypertension or diabetes. (65+ age group = {k["age65plus_group_pct"]}%, includes 65)', 'Week 6 SQL'],
        ['Appointment IDs (with detail)', f'{k["appointment_ids"]:,} ({k["detailed"]:,})', f'Detail = facility, department, date, patient ({k["detailed_pct"]}%)', 'D06'],
        ['Billed', rwf(k['billed']), 'All 60,000 bills', 'A03'],
        ['Collected', f'{rwf(k["collected"])} ({k["collection_pct"]}%)', 'Sum of payments', 'A04, A06'],
        ['Outstanding', f'{rwf(k["outstanding"])} on {k["bills_with_balance"]:,} bills', 'Billed minus paid (Billing.Status not used: matches payments on 33.4% of bills)', 'A05, A16'],
        ['Average bill / average unpaid balance', f'{rwf(k["avg_bill"])} / {rwf(k["avg_balance"])}', 'Per bill; per bill with balance', 'A09'],
        ['Insurance claims', f'{k["claims"]:,}', 'All claims', 'A08'],
        ['Claim approval rate', f'{k["approval_pct"]}%', f'Approved / all claims; none rejected; {k["claims_pending"]:,} Pending ({bn(k["pending_value"])})', 'A07'],
        ['Bills with no claim', f'{k["bills_no_claim"]:,} ({bn(k["bills_no_claim_value"])})', '29.9% of bills', 'E01'],
        ['Average satisfaction', f'{k["avg_rating"]} / 5', f'{k["feedback_n"]:,} ratings; {k["poor_pct"]}% poor (1-2); {k["good_pct"]}% good (4-5)', 'A10'],
        ['Admission rate', f'{k["admission_pct"]}%', f'All 60,000 IDs ({k["admission_pct_detailed"]}% on the 5,000 detailed)', 'A11, B05'],
        ['Average length of stay', f'{k["avg_los"]} days', 'Admissions', 'A12'],
        ['Referral rate', f'{k["referral_pct"]}%', 'All 60,000 IDs', 'A13'],
        ['Doctors / staff', f'{k["doctors"]} / {k["staff"]:,}', 'Staff table', 'A14'],
        ['Bed utilisation (modelled)', f'{k["bed_util_modelled_pct"]}%', f'Admission bed-days / ({k["beds"]:,} beds x 365); recorded status is "Available" for all beds', 'B07'],
        ['<b>No-show / attendance rate</b>', '<b>Not available</b>', 'No attendance field in the files I analysed; no valid proxy (D01-D04)', 'D01-D04'],
        ['Data Science model (reported by them)', 'Accuracy 64.8%; ROC-AUC 0.687', 'Baseline 62.4% / 0.677; not recomputed by me', 'X04 (consistency only)']]
st += [PageBreak(), P('4. Final KPIs', 'h1'),
       P(f'Every value below was recomputed independently in Python from the cleaned data and matched to the Week 6 SQL result files ({k["sql_crosscheck"]}). The base matters: figures for all 60,000 IDs differ from figures for the 5,000 detailed appointments, so each row states its base.'),
       tbl(rows, [44, 38, 64, 24])]

# 5 validated findings
st += [P('5. Validated findings and dashboard figures', 'h1'),
       tbl([['Finding', 'Evidence (Week 7 test)', 'Confidence'],
            ['Collection is about 90% in every facility, department, visit type and month.', 'C03: smallest p = 0.51', 'High'],
            ['Claim approval is about 50% for every insurer and bill-size quartile.', 'C04: smallest p = 0.077 (insurer)', 'High'],
            ['Satisfaction is about 3/5 with 40% poor in every segment; no trend over months.', 'C01, C02, C08', 'High'],
            ['No facility differs from the network average on satisfaction.', 'C06, C07: 0 of 20 outside ±1.96 SE', 'High'],
            ['Chronic-condition share (74.6%) is stable across gender and age.', 'C05', 'High'],
            ['Billing.Status and payment method are unreliable.', 'A16 (33.4% agreement); E01 (30% of Insurance payments have no claim)', 'High'],
            ['Facility, department, month and province views are a directional sample (8.3%).', 'B01-B09', 'High'],
            ['Dashboard cards change scope under any slicer; fixed in DAX v2 but not yet applied in Desktop.', 'B01-B11, B10 (emulated)', 'Fixed in code; Desktop check pending']],
           [88, 62, 20]),
       P('<b>Dashboard figures.</b> The expected value for every headline card is in Appendix A so the Power BI file can be checked line by line. '
         'I could not open the data inside the .pbix, so the dashboard’s own numbers are validated by emulating its relationships and measures (Week 7, tests B01-B11), not by reading them from the file.', 'small')]

# 6 visuals
st += [PageBreak(), P('6. Key visualisations', 'h1'),
       P('Each chart title states the finding. Axes start at zero.', 'small'),
       fig('f1_cash_exposure', 150), fig('f2_claim_status', 150), fig('f3_satisfaction', 150),
       P(f'Source: Week 6 cleaned data; {k["feedback_n"]:,} ratings, 60,000 bills, 42,036 claims.', 'small'),
       PageBreak(), fig('f4_facility_satisfaction', 150),
       P('Each facility’s interval overlaps the network average, so no facility should be ranked, rewarded or blamed on satisfaction. Facilities are based on the 1,756 ratings that link to a detailed appointment.', 'small'),
       fig('f5_coverage', 150),
       P('This is the main reason facility, department and time views are directional. Capturing these fields for every appointment is Recommendation 1.', 'small')]

# 7 attendance
st += [P('7. Attendance and no-show: what is known', 'h1'),
       tbl([['Source', 'What it says', 'Status'],
            ['My analytics data (Week 6 files)', 'No attendance, no-show, cancellation or status field in any of 27 tables. Every appointment has a diagnosis, bill and payment, so no valid proxy exists. 916 future-dated visits already carry payments and diagnoses. Demand is flat across weekdays (p = 0.69).', 'Tested (D01-D06); no-show rate not calculable'],
            ['Data Science model (their dataset)', 'Tuned Gradient Boosting: accuracy 62.4% → 64.8%, ROC-AUC 0.677 → 0.687. Error by type: Diagnostic Test 31.2 → 29.4%, Follow-up 38.7 → 34.3%, General Consultation 36.5 → 34.0%, Specialist Consultation 42.2 → 42.8%. Precision, recall and F1 are all 64.8%; Brier score 0.2246. Built on 5,000 appointment records (4,737 after excluding cancelled; 966 in the test set). Drivers: booking lead time, past no-show rate, distance to clinic; gender, day, time and reminder channel add almost nothing. Uses no billing, payment or claims fields. Calibration uneven at very low and very high scores.', 'Reported by Data Science (confirmed 17 Nov); not recomputed. Internal consistency checked (X04; Week 8 checks)'],
            ['Analytics support to the model', 'Segment variables (facility, department, visit type, gender, age, month) show no significant effect in my data; avoid Billing.Status, payment method and date logic on future-dated rows. Three hypotheses for the Specialist error (class balance, sample size, structure) sent to Data Science. Her reply (17 Nov) confirms the segment finding matches her results and that her model avoids the unreliable billing fields.', 'Exchange complete; Specialist structure check open']],
           [38, 100, 32]),
       fig('f6_ds_error_by_type', 150),
       P('<b>Checks I ran on the reported figures</b> (week8_crosstrack.py; inputs as reported by Data Science, not recomputed):'),
       tbl([['Check', 'Result', 'Verdict'],
            ['Internal consistency', 'Records 567 + 1,344 + 1,980 + 846 = 4,737 and test cases 109 + 271 + 406 + 180 = 966 (263 cancelled excluded from 5,000). Test-weighted error 35.2% = 100 - 64.8% accuracy.', '<b>Consistent</b>'],
            ['H1 class balance', 'No-show rate is 49.1-54.2% in every appointment type, so no type is imbalanced.', '<b>Rejected</b>'],
            ['H2 sample size', 'Specialist test n = 180, so 42.8% error has a 95% interval of about 35.6-50.0% (+/-7.2 points). Versus the other three types pooled (33.5%): z = 2.37, p = 0.018; after Bonferroni over 4 types p = 0.07. The 0.6-point change since tuning is within noise.', '<b>Suggestive, not conclusive</b> (type chosen because it was worst)'],
            ['H3 structure', 'Whether Specialist is booked differently (lead time, referral, distance) needs her appointment file.', '<b>Open</b>'],
            ['Model skill', 'Brier 0.2246 against 0.25 for a no-skill 50% forecast: about 10% better. Accuracy 64.8% vs 62.4% baseline.', '<b>Modest</b>']],
           [32, 104, 34]),
       P('<b>Reading the model results.</b> Specialist Consultation is the only type with no improvement, and the evidence points to a smaller test sample and possibly different booking behaviour, not to class imbalance or to anything in my segment variables. Calibration is wrong in both tails (low scores over-predict, high scores under-predict), which means scores are compressed towards the middle: the model ranks appointments better than it gives true probabilities. It should be used to prioritise reminders, not to decide who gets a slot.'),
       P('<b>Attribution note.</b> The per-type no-show rates (and so the finding that Specialist does not have the highest no-show rate) come from Data Science’s own table. My contribution was the negative finding on segment variables, the three hypotheses, the consistency checks and the cautions on billing fields.', 'small'),
       P('<b>What I would add with the appointment dataset</b> (not done, because I do not have it): no-show rate by lead-time band, weekday and time slot; prior-no-show effect; slot utilisation; and the structure check (H3) for Specialist Consultation.')]

# 8 insights and recs
st += [PageBreak(), P('8. Business insights and recommendations', 'h1'),
       tbl([['Insight', 'So what'],
            [f'{bn(k["pending_value"])} is in pending claims and {bn(k["bills_no_claim_value"])} in bills with no claim.', 'The biggest controllable cash issue is the claims process, not patient payment behaviour.'],
            [f'Collection is {k["collection_pct"]}% everywhere.', 'Do not run facility-specific collection campaigns; target by balance size.'],
            [f'Satisfaction {k["avg_rating"]}/5, {k["poor_pct"]:.0f}% poor, uniform.', 'A network service-experience problem; the feedback instrument itself needs reasons, not just ratings.'],
            ['Facility differences are statistical noise.', 'Facility league tables would misdirect investment.'],
            [f'Only {k["detailed_pct"]}% of appointments have detail; no attendance field.', 'Missed-appointment reduction cannot be managed until attendance and slot data are captured.']],
           [80, 90]),
       Spacer(1, 3 * mm),
       tbl([['#', 'Recommendation', 'Evidence', 'Owner', 'Success measure (baseline)'],
            ['1', 'Record attendance status (attended / no-show / cancelled) and facility, department and date for every appointment.', 'D01, X01, coverage 8.3%', 'HealthConnect data owner; Data Science needs it', f'Attendance recorded for all appointments (baseline: none)'],
            ['2', 'Fix the claims workflow: submit claims for unclaimed bills; review pending claims by age.', 'A07-A08, C04, E01', 'Finance / claims team', f'Claim coverage (70.1%) and pending value ({bn(k["pending_value"])})'],
            ['3', 'Target collections by balance size, not by facility.', 'C03', 'Finance', f'Outstanding ({rwf(k["outstanding"])}) and bills with balance ({k["bills_with_balance"]:,})'],
            ['4', 'Run a network-wide service-experience programme; capture reasons for low ratings.', 'C01, C02, C07', 'Operations / quality', f'Average rating ({k["avg_rating"]}) and poor share ({k["poor_pct"]}%)'],
            ['5', 'Pilot reminder prioritisation with Data Science’s model, under their documented limits, with a comparison group.', 'Model results (reported), X03', 'Data Science / Project Management', 'No-show rate with vs without model-prioritised reminders'],
            ['6', 'Suggestion for GenAI: scope administrative support around balances, claim status and billing questions, strictly within the approved Knowledge Base.', 'Claims and billing volumes (A03-A08)', 'GenAI / Project Management', 'To be defined with GenAI'],
            ['7', 'Agree one headline appointment count; retire facility ranking; apply DAX v2 in Desktop.', 'D06, C06, B01', 'Data Analytics / Project Management', 'Dashboard checklist complete']],
           [6, 56, 26, 34, 48]),
       P('Success measures are baselines taken from the validated KPIs; I have not set numeric targets because the data cannot support them.', 'small'),
       P('How the findings support HealthConnect decisions', 'h2'),
       tbl([['Decision', 'Supported by the evidence?', 'Why'],
            ['Where to focus administrative effort', 'Yes', 'Claims and collections are quantified and stable across segments.'],
            ['Which facility to invest in or fix', '<b>No</b>', 'No facility differs significantly on satisfaction, collection or claim approval.'],
            ['Reduce no-shows with reminders', 'Partly', 'Model gives modest discrimination; analytics cannot measure attendance.'],
            ['Plan beds or appointment slots', '<b>No</b>', 'Bed status is "Available" for all beds; modelled use 3.8%; slot data and capacity absent; weekday demand flat.'],
            ['Use payment method or bill status in decisions', '<b>No</b>', 'A16, E01.']],
           [52, 30, 88])]

# 10 cross-track
st += [PageBreak(), P('9. Cross-track integration', 'h1'),
       P('<b>Final integration record (Data Analytics → Data Science).</b> Evidence: Appendix C and Cross_Track/Data_Science_Reply_Transcript.md.'),
       tbl([['Field', 'Record'],
            ['1. Track collaborated with', 'Data Science (Shylet Nyazika), Slack, 12 Nov 2026.'],
            ['2. Dependency', 'Data Science needs validated findings and KPIs for model interpretation and a matching walkthrough; Data Analytics needs the no-show outcome.'],
            ['3. Output received', 'Week 7 summary (64.8% / 0.687 vs 62.4% / 0.677, per-type error, two rejected features) and 17 Nov reply: precision/recall/F1 64.8%, Brier 0.2246, 5,000 → 4,737 → 966 records, drivers (lead time, past no-show, distance), per-type no-show rates 49.1-54.2%, calibration, documentation changes.'],
            ['4. Output provided', 'Final KPIs, five validated findings, modelling implications, three hypotheses for the Specialist error, data request.'],
            ['5. Final integration activity', 'Sent final KPIs 17 Nov (10:36); received her reply; checked her figures for consistency (they reconcile), tested H1 (rejected) and H2 (suggestive, p = 0.07 after correction), agreed which KPI figures are quoted as mine and which as hers.'],
            ['6. What changed', 'Her documentation now states that segment variables carry little signal (matching my finding) and that her model uses no billing, payment or claims fields. She lists my 916 post-extraction rows overlap as an unchecked limitation. Model unchanged.'],
            ['7. How it improved the solution', 'Narrowed the Specialist error to sample size and booking structure by ruling out class balance; aligned the KPI figures; gave the model team data cautions; kept each side’s numbers clearly attributed.'],
            ['8. Evidence', 'Four Slack screenshots (Appendix C), transcripts, Week 7 tests X01-X04, Week 8 checks (Evidence/Week8_CrossTrack), handoff note, follow-up message.'],
            ['9. Contribution to the final presentation', 'Analytics section (slides 1-10): findings, KPIs, recommendations, and the model-analytics link. Data Science presents the model; I present how analytics informs and limits it.']],
           [46, 124]),
       P('Final integration matrix: status of my outputs', 'h2'),
       tbl([['Flow', 'Final contribution', 'Status'],
            ['Data Analytics → Data Science', 'Validated findings support model interpretation', '<b>Done</b> (both directions evidenced, 17 Nov)'],
            ['Data Analytics → Project Management', 'Insights and issue list support decisions (handoff note, issue log of 15 items)', 'Prepared; exchange not yet recorded'],
            ['Data Analytics → GenAI', 'Candidate administrative topics (Recommendation 6)', 'Suggestion only; not yet shared'],
            ['Data Analytics → ML Engineering', 'Data-quality constraints (future-dated rows, unreliable fields)', 'Not yet shared'],
            ['Data Science → Data Analytics', 'No-show outcome and per-type results', '<b>Done</b> for results (17 Nov); appointment file not received']],
           [48, 78, 44])]

# 11 limitations
st += [P('10. Limitations', 'h1'),
       *B(['<b>Attendance:</b> not measurable in the files I analysed; model results are Data Science’s, not recomputed. Whether my 916 future-dated rows overlap her appointment file has not been checked by either of us.',
           f'<b>Coverage:</b> facility, department, month and province views use {k["detailed_pct"]}% of appointments (about 1,756 ratings).',
           '<b>Dates and fields:</b> 916 future-dated records carry payments and diagnoses; Billing.Status, payment method and phone numbers are unreliable; Revenue_Summary (RWF 1.13bn) does not reconcile with billing (RWF 9.31bn).',
           '<b>Uniform results:</b> satisfaction, approval and collection are almost identical across segments; this can indicate synthetic or generated data, so conclusions are about this dataset.',
           '<b>Capacity:</b> no slot, bed-status or equipment-status data; bed utilisation is modelled, not measured.',
           '<b>Dashboard:</b> my numbers are validated by emulation; the .pbix’s internal data could not be read here.']),
       P('11. What is not completed (stated plainly)', 'h1'),
       tbl([['Item', 'Status', 'What is needed'],
            ['Attendance / no-show pattern analysis (brief task 6)', '<b>Not done</b> on a dataset (per-type rates only, as reported)', 'Her appointment file (lead time, weekday, slot, prior no-show)'],
            ['Power BI v2 changes and screenshots', '<b>Not done</b>', 'Apply Week 7 checklist in Desktop; re-export PDF'],
            ['Specialist Consultation explanation', '<b>Partly resolved</b>: H1 rejected, H2 suggestive, H3 open', 'Her appointment file for the structure check'],
            ['Exchanges with Project Management, GenAI, ML Engineering', 'Not recorded', 'Send outputs; record replies'],
            ['Individual video', 'Script ready; <b>recording is yours</b>', 'Record 5-10 minutes in your own voice']],
           [64, 34, 72])]

# evolution
st += [P('12. Evolution of the work', 'h1'),
       tbl([['Stage', 'What was produced', 'What it led to'],
            ['Week 5', 'Power BI analytics submission on the SwiftLog case study: KPIs, dashboard, executive report.', 'Method and tooling reused for HealthConnect.'],
            ['Week 6', 'HealthConnect Rwanda: 27 tables, PostgreSQL database, 89 queries, cleaning pipeline, 6-page dashboard, insights and data-quality reports, 14-slide deck.', 'Baseline KPIs and the data-coverage limits.'],
            ['Week 7', '54 tests, KPI recomputation, segment robustness, slicer-scope finding, DAX v2, Data Science exchange.', 'Trusted KPIs; withdrawn ranking; honest limits on attendance.'],
            ['Week 8', 'Final KPIs, validated findings, recommendations, executive summary, slides, video script, integration record.', 'Decision-support package.']],
           [20, 90, 60])]

# appendix A
exp = [['Page / card', 'Expected value (no slicer)', 'With every slicer item ticked', 'Dashboard shows', 'OK?'],
       ['Executive: Total Registered Patients', f'{k["patients"]:,}', 'unchanged', '', ''],
       ['Executive: Total Appointments', f'{k["appointment_ids"]:,}', f'{k["detailed"]:,}', '', ''],
       ['Executive: Total Revenue', f'{k["billed"]:,.0f}', '771,133,439', '', ''],
       ['Executive: Amount Collected', f'{k["collected"]:,.0f}', '694,551,320', '', ''],
       ['Executive: Outstanding Bills', f'{k["outstanding"]:,.0f}', '76,582,119', '', ''],
       ['Executive: Number of Doctors', f'{k["doctors"]}', 'unchanged', '', ''],
       ['Financial: Collection Rate', f'{k["collection_pct"]}%', '90.1%', '', ''],
       ['Financial: Claim Approval Rate', f'{k["approval_pct"]}%', '50.4%', '', ''],
       ['Financial: Average Billing Amount', f'{k["avg_bill"]:,}', 'about 154,000', '', ''],
       ['Clinical: Admission Rate', f'{k["admission_pct"]}%', '11.72%', '', ''],
       ['Clinical: Average Length of Stay', f'{k["avg_los"]} days', 'similar', '', ''],
       ['Operational: Bed Utilization (Modelled)', f'{k["bed_util_modelled_pct"]}%', '0.45%', '', ''],
       ['Operational: Beds per Room', f'{k["beds_per_room"]}', 'unchanged', '', ''],
       ['Patient experience: Average Satisfaction', f'{k["avg_rating"]}', '2.93', '', ''],
       ['Patient: Chronic Disease Rate', f'{k["chronic_pct"]}%', 'n/a (patients not linked to facility)', '', '']]
st += [PageBreak(), P('Appendix A. Dashboard figure check sheet', 'h1'),
       P('Open HealthConnect_Dashboard.pbix, read each card and fill the last two columns. The “every slicer ticked” column shows what the same card returns on the 5,000-appointment sample (Week 7 test B01-B07); it is expected behaviour of the Week 6 model, flagged as an issue and fixed in DAX v2.', 'small'),
       tbl(exp, [52, 32, 40, 30, 16]),
       P('Age note: “aged over 65” (66+) is 27.4%; the dashboard’s “65+” age group (65 and over) is 28.5%. Both are correct for their definitions.', 'small')]
# appendix B + C
st += [P('Appendix B. Deliverable map (Week 8 brief → file)', 'h1'),
       tbl([['Required item', 'File'],
            ['Final dashboard / report', 'Reports/Week8_Final_Analytics_Report.pdf; Dashboard/HealthConnect_Dashboard.pbix (Week 6 build; v2 pending)'],
            ['Final KPIs', 'Section 4; Data/Final_KPIs.csv; Reports/Week8_Analytics_Workbook.xlsx'],
            ['Validated findings; key visualisations', 'Sections 5-6; Figures/'],
            ['Business insights; recommendations', 'Section 8'],
            ['Analytical limitations; remaining issues', 'Sections 10-11'],
            ['Cross-track contribution', 'Section 9; Cross_Track/; Evidence/'],
            ['Executive summary', 'Reports/Week8_Executive_Summary.pdf'],
            ['Presentation slides / materials', 'Presentation/Week8_Analytics_Presentation.pptx and .pdf; Video/Individual_Video_Script.md']],
           [60, 110]),
       PageBreak(), P('Appendix C. Cross-track evidence (Slack, Data Science)', 'h1'),
       P('<b>Week 7 exchange, 12 November 2026.</b> Left: my message (09:14). Right: Data Science’s introduction and summary (08:03-08:36).', 'small')]
def pair(names):
    imgs = []
    for n in names:
        im = PI.open(f'{SH}/{n}'); w = 82 * mm; imgs.append(Image(f'{SH}/{n}', width=w, height=w * im.size[1] / im.size[0]))
    return Table([imgs], colWidths=[85 * mm, 85 * mm])
st += [pair(['W7_CrossTrack_01_my_message_to_DataScience.jpg', 'W7_CrossTrack_02_DataScience_summary.jpg']), PageBreak(),
       P('<b>Week 8 final integration, 17 November 2026.</b> Left: my final outputs sent to Data Science (10:36). Right: Data Science’s reply (screenshot shows the opening of the reply; full text in Cross_Track/Data_Science_Week8_Reply_Transcript.md).', 'small'),
       pair(['W8_CrossTrack_01_my_final_outputs_to_DataScience.jpg', 'W8_CrossTrack_02_DataScience_reply.jpg'])]
build(f'{PD}/Week8_Final_Analytics_Report.pdf', st, 'HealthConnect Final Analytics & Decision Support Report')

# =============================================================== EXECUTIVE SUMMARY (1 page)
es = [Spacer(1, 3 * mm), P('HealthConnect: Executive Summary of the Analytics', 'title'),
      P('Data Analytics track | Tatenda Mujati | November 2026', 'sub'), Spacer(1, 3 * mm), P(EXEC, 'box'),
      P('Final KPIs', 'h2'),
      tbl([['Patients', 'Billed / collected', 'Outstanding', 'Claims approved', 'Satisfaction', 'Attendance'],
           [f'{k["patients"]:,}', f'{bn(k["billed"])} / {k["collection_pct"]}%', f'{rwf(k["outstanding"])}', f'{k["approval_pct"]}% ({k["claims_pending"]:,} pending)', f'{k["avg_rating"]}/5 ({k["poor_pct"]:.0f}% poor)', '<b>Not measurable</b> in my data']],
           [24, 32, 30, 32, 28, 24]),
      P('What the evidence supports', 'h2'),
      *B(['<b>Focus administrative effort on claims and collections.</b> Quantified, stable across every segment.',
          '<b>Do not rank or reward facilities.</b> No facility differs significantly on satisfaction, collection or claim approval.',
          '<b>Capture attendance and appointment detail first.</b> Without it the project question (missed appointments) cannot be measured, and the Data Science model cannot be fully explained or targeted.',
          '<b>Use the model to prioritise reminders only,</b> with a comparison group. Accuracy 64.8% (baseline 62.4%) is a modest gain; error is highest for Specialist Consultation.']),
      P('Recommendations (priority order)', 'h2'),
      *B(['1. Record attendance status and appointment detail for every appointment.', '2. Fix the claims workflow (RWF 2.80bn unclaimed, RWF 2.44bn pending).',
          '3. Target collections by balance size.', '4. Network-wide service-experience programme; capture reasons for low ratings.', '5. Pilot model-prioritised reminders with a comparison group.']),
      P('Limitations', 'h2'),
      P(f'Facility, department and time views use {k["detailed_pct"]}% of appointments; Data Science results are as reported, not recomputed; results are very uniform across segments (possible synthetic data); capacity and slot data are absent. '
        'Not completed: attendance pattern analysis (dataset not available to me) and the Power BI v2 changes.'),
      P('Evidence: 54 Week 7 tests, KPI cross-check against SQL (11 exact matches), Slack exchange with Data Science.', 'small')]
build(f'{PD}/Week8_Executive_Summary.pdf', es, 'HealthConnect Executive Summary')
print('built')
