#!/usr/bin/env python3
"""Checks on the Data Science results reported by Shylet Nyazika (Slack, 17 Nov 2026).
Inputs are the figures she reported; they are NOT recomputed from her data (I do not have it).
Usage: week8_crosstrack.py <out_dir>"""
import sys, json, numpy as np
from scipy.stats import norm
OUT = sys.argv[1]
types = ['Diagnostic Test', 'Follow-up', 'General Consultation', 'Specialist Consultation']
n_model = [567, 1344, 1980, 846]; n_test = [109, 271, 406, 180]
err = [29.4, 34.3, 34.0, 42.8]; err_before = [31.2, 38.7, 36.5, 42.2]
acc = 64.8; total, excl_cancel, test = 5000, 4737, 966
res = {}
res['records_sum_ok'] = sum(n_model) == excl_cancel; res['test_sum_ok'] = sum(n_test) == test
res['cancelled_excluded'] = total - excl_cancel
w_err = sum(e * n for e, n in zip(err, n_test)) / test
res['weighted_test_error'] = round(w_err, 2); res['implied_accuracy'] = round(100 - w_err, 2); res['reported_accuracy'] = acc
res['consistent'] = bool(abs(100 - w_err - acc) < 0.2)
rows = []
for t, n, e, b in zip(types, n_test, err, err_before):
    p = e / 100; se = np.sqrt(p * (1 - p) / n)
    rows.append(dict(type=t, n_test=n, error_before=b, error_final=e, ci_low=round(100 * (p - 1.96 * se), 1), ci_high=round(100 * (p + 1.96 * se), 1), half_width=round(196 * se, 1)))
# Specialist vs all other types (pooled)
ns, ps = n_test[3], err[3] / 100; no = sum(n_test[:3]); po = sum(e * n for e, n in zip(err[:3], n_test[:3])) / no / 100
pp = (ns * ps + no * po) / (ns + no); z = (ps - po) / np.sqrt(pp * (1 - pp) * (1 / ns + 1 / no)); p = 2 * (1 - norm.cdf(abs(z)))
res.update(other_types_error=round(100 * po, 1), z_specialist_vs_rest=round(z, 2), p_uncorrected=round(p, 4), p_bonferroni4=round(min(1, 4 * p), 3))
# change in specialist error before->after is within noise
d = (err[3] - err_before[3]) / 100; se_d = np.sqrt(ps * (1 - ps) / ns) * np.sqrt(2)
res['specialist_change_pts'] = round(100 * d, 1); res['specialist_change_within_noise'] = bool(abs(d) < 1.96 * se_d)
res['brier_reported'] = 0.2246; res['brier_no_skill'] = 0.25; res['brier_skill_pct'] = round(100 * (1 - 0.2246 / 0.25), 1)
res['h1_class_balance'] = 'Rejected: reported no-show rate is 49.1-54.2% in every type, so classes are balanced and Specialist is not special.'
res['h2_sample_size'] = f'Partly supported: Specialist test n = 180, 95% interval about +/-{rows[3]["half_width"]} points; but 42.8% vs {res["other_types_error"]}% for the other types is z = {res["z_specialist_vs_rest"]}, p = {res["p_uncorrected"]} (uncorrected), {res["p_bonferroni4"]} after Bonferroni over 4 types. Suggestive, not conclusive; the type was picked because it was worst.'
res['h3_structure'] = 'Open: needs the appointment file (is Specialist booked differently, e.g. by lead time or referral).'
json.dump(dict(summary=res, per_type=rows), open(f'{OUT}/crosstrack_checks.json', 'w'), indent=1)
import csv
with open(f'{OUT}/crosstrack_per_type.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]) + ['n_model_records']); w.writeheader()
    for r, n in zip(rows, n_model): w.writerow({**r, 'n_model_records': n})
print(json.dumps(res, indent=1))
