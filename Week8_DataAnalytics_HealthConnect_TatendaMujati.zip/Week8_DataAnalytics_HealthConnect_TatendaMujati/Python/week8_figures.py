#!/usr/bin/env python3
"""Final visuals for the Week 8 report and deck.  Usage: week8_figures.py <kpi_dir> <week7_evidence_dir> <figs_dir> <week6_root>"""
import sys, json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
KD, W7, FG, W6 = sys.argv[1:5]
k = json.load(open(f'{KD}/final_kpis.json'))
BLUE, GREY, RED, INK, LB = '#2a6fb0', '#9aa5b1', '#c0392b', '#1f2933', '#d6e4f5'
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': '#cbd2d9', 'text.color': INK,
                     'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK, 'figure.dpi': 200})
def save(n): plt.tight_layout(); plt.savefig(f'{FG}/{n}.png'); plt.close()

fig, ax = plt.subplots(figsize=(7.2, 2.9))
lab = ['Bills with no insurance claim', 'Claims still Pending', 'Unpaid balances (billed - paid)']
val = [k['bills_no_claim_value'] / 1e9, k['pending_value'] / 1e9, k['outstanding'] / 1e9]
ax.barh(lab, val, color=[BLUE, BLUE, GREY], height=.55)
for i, v in enumerate(val): ax.text(v + .05, i, f'RWF {v:.2f}bn', va='center')
ax.set_xlim(0, 3.6); ax.set_xlabel('RWF billions (the three overlap; do not add them)')
ax.set_title('RWF 2.80bn of bills are unclaimed and RWF 2.44bn is pending', loc='left', fontsize=10.5)
save('f1_cash_exposure')

fig, ax = plt.subplots(figsize=(7.2, 1.9))
parts = [('Approved', k['claims_approved'], BLUE), ('Pending', k['claims_pending'], RED), ('No claim', k['bills_no_claim'], GREY)]
left = 0
for n, v, c in parts:
    ax.barh([0], [v], left=left, color=c, height=.5, edgecolor='white', linewidth=2)
    ax.text(left + v / 2, 0, f'{n}\n{v:,} ({100*v/60000:.1f}%)', ha='center', va='center', color='white', fontsize=9, fontweight='bold'); left += v
ax.set_xlim(0, 60000); ax.set_yticks([]); ax.set_xlabel('Bills (all 60,000)'); ax.spines['left'].set_visible(False)
ax.set_title('Only 35% of bills are claimed and approved', loc='left', fontsize=10.5)
save('f2_claim_status')

fb = pd.read_csv(f'{W6}/Data/Cleaned/patient_feedback.csv'); d = fb.rating.value_counts(normalize=True).sort_index() * 100
fig, ax = plt.subplots(figsize=(7.2, 2.8))
ax.bar(d.index.astype(str), d.values, color=[RED, RED, GREY, BLUE, BLUE], width=.62)
for x, v in zip(d.index.astype(str), d.values): ax.text(x, v + .5, f'{v:.1f}%', ha='center')
ax.set_ylim(0, 26); ax.set_xlabel('Rating (1 = poor, 5 = excellent)'); ax.set_ylabel('% of 21,064 ratings')
ax.set_title(f'Average {k["avg_rating"]:.2f}/5: ratings spread evenly; {k["poor_pct"]:.0f}% poor, {k["good_pct"]:.0f}% good', loc='left', fontsize=10.5)
save('f3_satisfaction')

t = pd.read_csv(f'{W7}/evidence_facility_tiers.csv', index_col=0).sort_values('mean')
fig, ax = plt.subplots(figsize=(7.2, 4.0)); y = np.arange(len(t))
ax.hlines(y, t['mean'] - 1.96 * t.se, t['mean'] + 1.96 * t.se, color=GREY, lw=3); ax.plot(t['mean'], y, 'o', color=BLUE)
ax.axvline(k['avg_rating'], color=INK, ls='--', lw=1); ax.set_yticks(y); ax.set_yticklabels(t.index)
ax.set_xlabel(f'Average satisfaction (1-5) with 95% interval; dashed = network {k["avg_rating"]:.2f}')
ax.set_title('No facility is statistically different from the network average', loc='left', fontsize=10.5)
save('f4_facility_satisfaction')

fig, ax = plt.subplots(figsize=(7.2, 1.7))
ax.barh([0], [k['detailed']], color=BLUE, height=.5, edgecolor='white', linewidth=2); ax.barh([0], [60000 - k['detailed']], left=k['detailed'], color=LB, height=.5, edgecolor='white', linewidth=2)
ax.text(k['detailed'] / 2, 0, f'{k["detailed"]:,}', ha='center', va='center', color='white', fontsize=8.5, fontweight='bold')
ax.text(k['detailed'] + 55000 / 2, 0, '5,000 have detail; 55,000 IDs have no facility, department, date or patient', ha='center', va='center', fontsize=9)
ax.set_xlim(0, 60000); ax.set_yticks([]); ax.spines['left'].set_visible(False); ax.set_xlabel('Appointment IDs')
ax.set_title(f'Facility, department and time views rest on {k["detailed_pct"]}% of appointments', loc='left', fontsize=10.5)
save('f5_coverage')

types = ['Diagnostic\nTest', 'Follow-up', 'General\nConsultation', 'Specialist\nConsultation']; bef = [31.2, 38.7, 36.5, 42.2]; aft = [29.4, 34.3, 34.0, 42.8]
fig, ax = plt.subplots(figsize=(7.2, 3.2)); x = np.arange(4); w = .36
ax.bar(x - w / 2, bef, w, color=GREY, label='Before tuning'); nt = [109, 271, 406, 180]; ci = [196 * np.sqrt(a / 100 * (1 - a / 100) / n) for a, n in zip(aft, nt)]
ax.bar(x + w / 2, aft, w, color=[BLUE, BLUE, BLUE, RED], label='Final model (95% interval)', yerr=ci, error_kw=dict(ecolor=INK, lw=1, capsize=3))
for i in range(4):
    ax.text(x[i] - w / 2, bef[i] + .6, f'{bef[i]}', ha='center', fontsize=8.5); ax.text(x[i] + w / 2 + .12, aft[i] + ci[i] + .6, f'{aft[i]}', ha='center', fontsize=8.5)
ax.set_xticks(x); ax.set_xticklabels(types); ax.set_ylim(0, 58); ax.set_ylabel('Model error rate, %'); ax.legend(frameon=False, loc='upper left', ncol=2)
ax.set_title('Data Science model: error fell for 3 of 4 types; Specialist did not, and its interval is widest', loc='left', fontsize=10.5)
fig.text(0.01, 0.005, 'Source: Data Science (Slack, 12 and 17 Nov 2026), not recomputed. Intervals use reported test sizes.', fontsize=7.5, color='#616e7c')
plt.tight_layout(rect=(0, .03, 1, 1)); plt.savefig(f'{FG}/f6_ds_error_by_type.png'); plt.close()
print('figs ok')
