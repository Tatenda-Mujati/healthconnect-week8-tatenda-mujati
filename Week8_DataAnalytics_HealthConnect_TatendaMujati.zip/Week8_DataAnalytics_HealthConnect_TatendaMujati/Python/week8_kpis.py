#!/usr/bin/env python3
"""Week 8 final KPI set, computed from the Week 6 cleaned data and cross-checked against the Week 6 SQL result files.
Usage: week8_kpis.py <week6_package_root> <out_dir>"""
import sys, os, json
import numpy as np, pandas as pd
ROOT, OUT = sys.argv[1:3]; os.makedirs(OUT, exist_ok=True)
C = lambda n: pd.read_csv(os.path.join(ROOT, 'Data', 'Cleaned', n + '.csv'))
K = lambda k: pd.read_csv(os.path.join(ROOT, 'SQL', 'query_results_kpi', k + '.csv'))
pat, ap, bi, pay, cl, fb, reg, adm, ref, stf, rooms, beds = (C(x) for x in 'patients appointments billing payments insurance_claims patient_feedback appointment_registry admissions referrals staff rooms beds'.split())
paid = pay.groupby('billing_id').amount_paid.sum()
b = bi.merge(paid.rename('paid'), left_on='billing_id', right_index=True, how='left').fillna({'paid': 0})
b['out'] = b.amount - b.paid
b = b.merge(cl[['billing_id', 'claim_amount', 'status']].rename(columns={'status': 'claim_status'}), on='billing_id', how='left')
chronic = pat.chronic_condition.notna()           # pandas reads the text 'None' as missing
k = {}
k['patients'] = len(pat); k['avg_age'] = round(pat.age.mean(), 1); k['male_pct'] = round(100 * (pat.gender == 'Male').mean(), 1)
k['chronic_pct'] = round(100 * chronic.mean(), 1); k['age_over65_pct'] = round(100 * (pat.age > 65).mean(), 1); k['age65plus_group_pct'] = round(100 * (pat.age_group == '65+').mean(), 1)
k['appointment_ids'] = len(reg); k['detailed'] = len(ap); k['detailed_pct'] = round(100 * len(ap) / len(reg), 1)
k['billed'] = float(b.amount.sum()); k['collected'] = float(b.paid.sum()); k['outstanding'] = float(b.out.sum())
k['collection_pct'] = round(100 * b.paid.sum() / b.amount.sum(), 1)
bal = b[b.out > 0.005]; k['bills_with_balance'] = len(bal); k['avg_balance'] = round(bal.out.mean())
k['avg_bill'] = round(b.amount.mean())
k['claims'] = len(cl); k['approval_pct'] = round(100 * (cl.status == 'Approved').mean(), 2)
k['claims_approved'] = int((cl.status == 'Approved').sum()); k['claims_pending'] = int((cl.status == 'Pending').sum())
k['pending_value'] = float(cl[cl.status == 'Pending'].claim_amount.sum())
noclaim = b[b.claim_status.isna()]; k['bills_no_claim'] = len(noclaim); k['bills_no_claim_value'] = float(noclaim.amount.sum())
k['avg_rating'] = round(fb.rating.mean(), 2); k['poor_pct'] = round(100 * (fb.rating <= 2).mean(), 1); k['good_pct'] = round(100 * (fb.rating >= 4).mean(), 1)
k['feedback_n'] = len(fb); k['feedback_response_pct'] = round(100 * len(fb) / len(reg), 1)
k['admission_pct'] = round(100 * len(adm) / len(reg), 2); k['admission_pct_detailed'] = round(100 * ap.appointment_id.isin(adm.appointment_id).mean(), 2)
k['avg_los'] = round(adm.length_of_stay_days.mean(), 2); k['referral_pct'] = round(100 * len(ref) / len(reg), 2)
k['doctors'] = int((stf.staff_type == 'Doctor').sum()); k['staff'] = len(stf)
k['bed_util_modelled_pct'] = round(100 * adm.length_of_stay_days.sum() / (len(beds) * 365), 2); k['beds'] = len(beds); k['beds_per_room'] = round(len(beds) / len(rooms), 2)
# cross-check against the Week 6 SQL result files (independent route)
chk = [('patients', K('K01').iloc[0, 0]), ('avg_age', round(K('K11').iloc[0, 0], 1)), ('billed', K('K39').total_billed_rwf.iloc[0]), ('collected', K('K39').collected_rwf.iloc[0]),
       ('outstanding', K('K39').outstanding_rwf.iloc[0]), ('approval_pct', K('K41').approval_rate_pct.iloc[0]), ('claims', K('K41').claims.iloc[0]), ('avg_bill', K('K42').avg_bill_rwf.iloc[0]),
       ('admission_pct', K('K22').admission_rate_pct_all.iloc[0]), ('avg_los', K('K23').avg_length_of_stay_days.iloc[0]), ('referral_pct', K('K16').referral_rate_pct.iloc[0])]
bad = [(n, k[n], v) for n, v in chk if abs(float(k[n]) - float(v)) > 1e-6 * max(1, abs(float(v)))]
assert not bad, bad
k['sql_crosscheck'] = f'{len(chk)} KPIs match the Week 6 SQL result files exactly'
json.dump(k, open(f'{OUT}/final_kpis.json', 'w'), indent=1, default=float)
print(json.dumps({x: k[x] for x in ['pending_value', 'bills_no_claim', 'bills_no_claim_value', 'bills_with_balance', 'avg_balance', 'poor_pct', 'good_pct', 'beds_per_room', 'bed_util_modelled_pct']}))
