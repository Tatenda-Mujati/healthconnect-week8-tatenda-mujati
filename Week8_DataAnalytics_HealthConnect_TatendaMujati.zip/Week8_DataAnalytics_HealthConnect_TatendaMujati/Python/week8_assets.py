#!/usr/bin/env python3
"""Builds Final_KPIs.csv, the Week 8 workbook and the 10-slide analytics presentation.
Usage: week8_assets.py <kpi_dir> <figs_dir> <out_root>"""
import sys, os, json
import pandas as pd
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
KD, FG, OUT = sys.argv[1:4]
k = json.load(open(f'{KD}/final_kpis.json'))
os.makedirs(f'{OUT}/Data', exist_ok=True); os.makedirs(f'{OUT}/Reports', exist_ok=True); os.makedirs(f'{OUT}/Presentation', exist_ok=True)
bn = lambda v: f'RWF {v/1e9:.2f}bn'; rwf = lambda v: f'RWF {v:,.0f}'

# ------------------------------------------------------------ Final KPIs csv
rows = [
 ('Registered patients', k['patients'], 'count', 'All patients', 'Week 7 A01'),
 ('Average patient age', k['avg_age'], 'years', 'All patients', 'A02'),
 ('Male share', k['male_pct'], '%', 'All patients', 'Week 6 SQL'),
 ('Chronic condition share (asthma, hypertension or diabetes)', k['chronic_pct'], '%', 'All patients', 'Week 6 SQL'),
 ('Appointment IDs', k['appointment_ids'], 'count', 'Billing / diagnoses / feedback', 'D06'),
 ('Appointments with facility, department, date detail', k['detailed'], 'count', f'{k["detailed_pct"]}% of IDs', 'D06'),
 ('Total billed', k['billed'], 'RWF', 'All 60,000 bills', 'A03'),
 ('Collected', k['collected'], 'RWF', 'Sum of payments', 'A04'),
 ('Collection rate', k['collection_pct'], '%', 'Collected / billed', 'A06'),
 ('Outstanding', k['outstanding'], 'RWF', 'Billed minus paid', 'A05'),
 ('Bills with a balance', k['bills_with_balance'], 'count', 'Billed minus paid > 0', 'A05'),
 ('Average bill', k['avg_bill'], 'RWF', 'All bills', 'A09'),
 ('Insurance claims', k['claims'], 'count', 'All claims', 'A08'),
 ('Claim approval rate', k['approval_pct'], '%', 'Approved / all claims', 'A07'),
 ('Claims pending', k['claims_pending'], 'count', 'Status Pending', 'A07'),
 ('Pending claim value', k['pending_value'], 'RWF', 'Pending claims', 'A07'),
 ('Bills with no claim', k['bills_no_claim'], 'count', 'All bills', 'E01'),
 ('Value of bills with no claim', k['bills_no_claim_value'], 'RWF', 'Bills with no claim', 'E01'),
 ('Average satisfaction', k['avg_rating'], '/5', f'{k["feedback_n"]:,} ratings', 'A10'),
 ('Poor ratings (1-2)', k['poor_pct'], '%', 'Ratings', 'C02'),
 ('Admission rate', k['admission_pct'], '%', f'All 60,000 IDs ({k["admission_pct_detailed"]}% on the 5,000 detailed)', 'A11'),
 ('Average length of stay', k['avg_los'], 'days', 'Admissions', 'A12'),
 ('Referral rate', k['referral_pct'], '%', 'All 60,000 IDs', 'A13'),
 ('Doctors', k['doctors'], 'count', 'Staff table', 'A14'),
 ('Bed utilisation (modelled)', k['bed_util_modelled_pct'], '%', 'Admission bed-days / (beds x 365); not measured', 'B07'),
 ('No-show / attendance rate', 'NOT AVAILABLE', '', 'No attendance field in the files analysed', 'D01-D04'),
]
kdf = pd.DataFrame(rows, columns=['KPI', 'Value', 'Unit', 'Base / definition', 'Validation'])
kdf.to_csv(f'{OUT}/Data/Final_KPIs.csv', index=False)

# ------------------------------------------------------------ workbook
find = pd.DataFrame([
 ['Collection is about 90% in every facility, department, visit type and month', 'C03 (smallest p = 0.51)', 'High'],
 ['Claim approval is about 50% for every insurer and bill-size quartile', 'C04 (smallest p = 0.077)', 'High'],
 ['Satisfaction is about 3/5, 40% poor, in every segment; no monthly trend', 'C01, C02, C08', 'High'],
 ['No facility differs from the network average on satisfaction', 'C06, C07', 'High'],
 ['Chronic-condition share is stable across gender and age', 'C05', 'High'],
 ['Billing.Status and payment method are unreliable', 'A16, E01', 'High'],
 ['Facility, department, month and province views are a directional sample (8.3%)', 'B01-B09', 'High'],
 ['Dashboard cards change scope under any slicer (fixed in DAX v2; Desktop check pending)', 'B01-B11', 'Fixed in code, unconfirmed in Desktop'],
], columns=['Finding', 'Evidence (Week 7 test)', 'Confidence'])
rec = pd.DataFrame([
 [1, 'Record attendance status and facility, department, date for every appointment', 'D01, X01, coverage 8.3%', 'Data owner; Data Science', 'Attendance recorded for all appointments (baseline: none)'],
 [2, 'Fix the claims workflow: submit claims for unclaimed bills; review pending claims by age', 'A07-A08, C04, E01', 'Finance / claims', f'Claim coverage (70.1%); pending value ({bn(k["pending_value"])})'],
 [3, 'Target collections by balance size, not facility', 'C03', 'Finance', f'Outstanding ({rwf(k["outstanding"])}); bills with balance ({k["bills_with_balance"]:,})'],
 [4, 'Network-wide service-experience programme; capture reasons for low ratings', 'C01, C02, C07', 'Operations / quality', f'Average rating ({k["avg_rating"]}); poor share ({k["poor_pct"]}%)'],
 [5, 'Pilot model-prioritised reminders with a comparison group, under Data Science\'s documented limits', 'Reported model results; X03', 'Data Science / PM', 'No-show rate with vs without model-prioritised reminders'],
 [6, 'Scope GenAI administrative support around balances, claim status and billing (within the approved Knowledge Base)', 'A03-A08', 'GenAI / PM', 'To be defined with GenAI'],
 [7, 'Agree one headline appointment count; retire facility ranking; apply DAX v2 in Desktop', 'D06, C06, B01', 'Data Analytics / PM', 'Checklist complete'],
], columns=['#', 'Recommendation', 'Evidence', 'Owner', 'Success measure (baseline)'])
chk = pd.DataFrame([
 ['Executive: Total Registered Patients', f'{k["patients"]:,}', 'unchanged'], ['Executive: Total Appointments', f'{k["appointment_ids"]:,}', f'{k["detailed"]:,}'],
 ['Executive: Total Revenue', f'{k["billed"]:,.0f}', '771,133,439'], ['Executive: Amount Collected', f'{k["collected"]:,.0f}', '694,551,320'],
 ['Executive: Outstanding Bills', f'{k["outstanding"]:,.0f}', '76,582,119'], ['Executive: Number of Doctors', f'{k["doctors"]}', 'unchanged'],
 ['Financial: Collection Rate', f'{k["collection_pct"]}%', '90.1%'], ['Financial: Claim Approval Rate', f'{k["approval_pct"]}%', '50.4%'],
 ['Financial: Average Billing Amount', f'{k["avg_bill"]:,}', 'about 154,000'], ['Clinical: Admission Rate', f'{k["admission_pct"]}%', '11.72%'],
 ['Clinical: Average Length of Stay', f'{k["avg_los"]} days', 'similar'], ['Operational: Bed Utilization (Modelled)', f'{k["bed_util_modelled_pct"]}%', '0.45%'],
 ['Operational: Beds per Room', f'{k["beds_per_room"]}', 'unchanged'], ['Patient experience: Average Satisfaction', f'{k["avg_rating"]}', '2.93'],
 ['Patient: Chronic Disease Rate', f'{k["chronic_pct"]}%', 'n/a'],
], columns=['Card', 'Expected (no slicer)', 'Expected (every slicer item ticked)'])
chk['Dashboard shows'] = ''; chk['OK?'] = ''
openi = pd.DataFrame([
 ['Attendance / no-show pattern analysis (brief task 6)', 'NOT DONE on a dataset (per-type rates only, as reported)', 'Data Science appointment file (lead time, weekday, slot, prior no-show)', 'Data Science'],
 ['Power BI v2 changes and screenshots', 'NOT DONE', 'Apply Week 7 checklist in Desktop; re-export PDF', 'Data Analytics (me)'],
 ['Specialist Consultation explanation', 'PARTLY RESOLVED: H1 rejected, H2 suggestive (p = 0.07 after correction), H3 open', 'Appointment file for the structure check', 'Data Science'],
 ['Exchanges with Project Management, GenAI, ML Engineering', 'NOT RECORDED', 'Send outputs, record replies, add evidence', 'Data Analytics (me)'],
 ['Individual video', 'SCRIPT READY', 'Record 5-10 min in own voice', 'Data Analytics (me)'],
 ['GitHub repository update', 'TO DO', 'Push package, add link to README and submission form', 'Data Analytics (me)'],
], columns=['Item', 'Status', 'What is needed', 'Owner'])
with pd.ExcelWriter(f'{OUT}/Reports/Week8_Analytics_Workbook.xlsx', engine='xlsxwriter') as w:
    hdr = w.book.add_format({'bold': True, 'bg_color': '#2A6FB0', 'font_color': 'white', 'text_wrap': True, 'valign': 'top', 'border': 1}); wrap = w.book.add_format({'text_wrap': True, 'valign': 'top'})
    for n, d in [('Final_KPIs', kdf), ('Validated_Findings', find), ('Recommendations', rec), ('Dashboard_Check_Sheet', chk), ('Open_Items', openi)]:
        d.to_excel(w, sheet_name=n, index=False); ws = w.sheets[n]
        for i, c in enumerate(d.columns):
            ws.write(0, i, c, hdr); ws.set_column(i, i, min(70, max(14, int(d[c].astype(str).str.len().quantile(.9)) + 2)), wrap)
        ws.freeze_panes(1, 0)

# ------------------------------------------------------------ presentation (10 slides)
INK, BLUE, GREY, RED = RGBColor(0x1f, 0x29, 0x33), RGBColor(0x2a, 0x6f, 0xb0), RGBColor(0x61, 0x6e, 0x7c), RGBColor(0xc0, 0x39, 0x2b)
prs = Presentation(); prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
blank = prs.slide_layouts[6]
def tb(sl, x, y, w, h, text, size=20, bold=False, color=INK, align=None, bul=False, head=False):
    t = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = t.text_frame; tf.word_wrap = True
    lines = text if isinstance(text, list) else [text]
    for i, ln in enumerate(lines):
        if bul and ln and not (head and i == 0) and not ln[0].isdigit(): ln = '\u2022 ' + ln
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.text = ln; p.font.size = Pt(size); p.font.bold = bold or (head and i == 0); p.font.color.rgb = color; p.space_after = Pt(8)
        if align: p.alignment = align
    return t
def slide(title, notes):
    s = prs.slides.add_slide(blank)
    bar = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(0.12)); bar.fill.solid(); bar.fill.fore_color.rgb = BLUE; bar.line.fill.background()
    tb(s, 0.6, 0.35, 12.1, 1.1, title, 30, True)
    tb(s, 0.6, 7.0, 12, 0.35, 'HealthConnect | Data Analytics | Tatenda Mujati | AnalystLab Africa Week 8', 11, False, GREY)
    s.notes_slide.notes_text_frame.text = notes
    return s
def pic(s, name, x, y, w):
    s.shapes.add_picture(f'{FG}/{name}.png', Inches(x), Inches(y), width=Inches(w))
def tile(s, x, y, w, label, value, color=BLUE):
    r = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(1.5)); r.fill.solid(); r.fill.fore_color.rgb = RGBColor(0xee, 0xf2, 0xf6); r.line.fill.background()
    tb(s, x + .15, y + .1, w - .3, .6, value, 26, True, color); tb(s, x + .15, y + .85, w - .3, .6, label, 14, False, GREY)

s = slide('HealthConnect: what the data shows, and what it cannot yet show', 'Introduce yourself: name, Data Analytics track, HealthConnect Clinic project, the problem: reduce missed appointments and improve patient support.')
tb(s, .6, 1.8, 12, 3, ['Tatenda Mujati | Data Analytics track', 'AnalystLab Africa Experience Lab, Week 8: Final Integration & Showcase', '', 'Project question: How can HealthConnect Clinic use data and AI to reduce missed appointments and improve the patient support experience?'], 22)
s = slide('My role: turn the data into decisions I can stand behind', 'My responsibility: validated KPIs, findings, dashboard, recommendations, limitations. Weeks 5-7 produced the analysis; Week 8 is the decision-support package.')
tb(s, .6, 1.6, 12, 5, ['Week 5-6: built the analytics (SQL database, cleaning pipeline, Power BI dashboard, insights report).', 'Week 7: tested it with 54 tests; fixed the issues I could.', 'Week 8: final KPIs, validated findings, recommendations, limits, and how my work connects to Data Science.', '', 'Rule I worked by: report only what the evidence supports.'], 22, bul=True)
s = slide('The data: 20,000 patients, 60,000 appointments, but only 8.3% have detail', 'Explain coverage. All 60,000 appointment IDs appear in billing, diagnoses and feedback; only 5,000 have facility, department and date. So facility and time views are directional. No attendance field exists in my files.')
pic(s, 'f5_coverage', .6, 1.7, 12.1); tb(s, .6, 5.0, 12, 1.8, ['27 source tables cleaned and loaded into PostgreSQL; every figure recomputed independently and matched to SQL.', 'No attendance or no-show field in my files, and no valid proxy (4 tests).'], 20, bul=True)
s = slide('Final KPIs (each recomputed and matched to SQL)', 'Walk the tiles quickly. Stress the base: 60,000 IDs vs 5,000 detailed. Outstanding is billed minus paid because Billing.Status matches payments on only 33.4% of bills.')
tiles = [('Patients', f'{k["patients"]:,}'), ('Billed', bn(k['billed'])), ('Collected', f'{k["collection_pct"]}%'), ('Outstanding', bn(k['outstanding'])), ('Claim approval', f'{k["approval_pct"]:.0f}%'), ('Satisfaction', f'{k["avg_rating"]} / 5'), ('Admission rate', f'{k["admission_pct"]}%'), ('No-show rate', 'Not available')]
for i, (l, v) in enumerate(tiles): tile(s, .6 + (i % 4) * 3.1, 1.8 + (i // 4) * 1.9, 2.9, l, v, RED if l == 'No-show rate' else BLUE)
tb(s, .6, 5.8, 12, 1, 'Collected = sum of payments. Outstanding = billed minus paid. Full table: Final_KPIs.csv.', 16, False, GREY)
s = slide('Insurance claims are the biggest cash lever', f'{bn(k["bills_no_claim_value"])} in {k["bills_no_claim"]:,} bills has no claim; {k["claims_pending"]:,} claims worth {bn(k["pending_value"])} are pending. Approval is about 50% for every insurer and bill size, so this is a process issue.')
pic(s, 'f2_claim_status', .6, 1.6, 7.2); pic(s, 'f1_cash_exposure', .6, 3.7, 7.2)
tb(s, 8.1, 1.8, 4.7, 5, [f'{bn(k["bills_no_claim_value"])} in bills with no claim', f'{bn(k["pending_value"])} in {k["claims_pending"]:,} pending claims', 'Approval about 50% for every insurer and bill size', 'So fix the process, not one insurer'], 20, bul=True)
s = slide('Satisfaction is a network problem, not a facility problem', 'Average 2.99/5, 40% poor, 40% good, the same in every facility, department, visit type and month. Every facility interval overlaps the network average, so I withdrew the facility ranking from the dashboard.')
pic(s, 'f4_facility_satisfaction', .6, 1.5, 7.4); tb(s, 8.3, 1.8, 4.5, 5, [f'{k["avg_rating"]}/5 average; {k["poor_pct"]:.0f}% poor', '0 of 20 facilities differ from the network', 'No monthly trend', 'Do not rank or reward facilities'], 20, bul=True)
s = slide('Attendance: what I can and cannot say', 'My files have no attendance field. The Data Science model, built on her dataset, predicts no-shows: accuracy 62.4% to 64.8%, AUC 0.677 to 0.687, Brier 0.2246, 5,000 records, 4,737 after cancelled ones, 966 in the test set. It is driven by lead time, past no-show rate and distance. Gender, day, time and reminder channel add almost nothing, which matches my finding that segment variables carry little signal. I checked her figures for consistency; I did not recompute the model.')
tb(s, .6, 1.6, 5.4, 5, ['My data: no attendance field, no valid proxy; 916 future-dated visits already paid.', 'Her model (reported): 64.8% accuracy, AUC 0.687, Brier 0.2246 (about 10% better than guessing). Drivers: lead time, past no-show, distance.', 'Specialist error 42.8%: class imbalance ruled out (no-show rate 49-54% in every type); small sample (n = 180, +/-7 points) is a partial explanation; booking structure still to check.'], 18, bul=True)
pic(s, 'f6_ds_error_by_type', 6.2, 1.6, 6.7)
s = slide('Cross-track: Data Analytics and Data Science exchanged real outputs', 'Two Slack exchanges, 12 and 17 November. Week 7: Shylet asked for findings that explain the Specialist error and for my final KPIs. Week 8: I sent final KPIs, validated findings and cautions; she replied with model details and confirmed her figures can be quoted. I checked that her numbers reconcile (4,737 and 966 records sum correctly; weighted error equals 100 minus accuracy), rejected H1, found H2 suggestive, and left H3 open. Be clear which numbers are hers and which are mine.')
tb(s, .6, 1.6, 6, 5, ['I sent: final KPIs, five validated findings, cautions (unreliable fields, future-dated rows).', 'I received: model details, per-type error and no-show rates, drivers, calibration, documentation changes.', 'I checked: her figures reconcile; H1 rejected; H2 suggestive (p = 0.07 after correction); H3 open.'], 19, bul=True)
tb(s, 6.9, 1.6, 5.9, 5, ['Her documentation now states segment variables add almost nothing (matches my finding).', 'Her model uses no billing, payment or claims fields, so my data cautions do not affect it.', 'Her numbers are cited as hers; mine as mine.', 'Evidence: four Slack screenshots, transcripts, tests X01-X04 and Week 8 checks.'], 19, bul=True)
s = slide('Recommendations, in priority order', 'Read the five. Emphasise that attendance data capture comes first because the project question cannot be measured without it. No numeric targets because the data cannot support them; baselines are given.')
tb(s, .6, 1.6, 12.1, 5.2, ['1. Record attendance status and appointment detail for every appointment.', f'2. Fix the claims workflow ({bn(k["bills_no_claim_value"])} unclaimed, {bn(k["pending_value"])} pending).', '3. Target collections by balance size, not by facility.', '4. Run a network-wide service-experience programme and capture reasons for low ratings.', '5. Pilot model-prioritised reminders with a comparison group.'], 22)
s = slide('Limitations and what is not finished', 'Be direct: attendance pattern analysis not done on a dataset because the appointment file is with Data Science; Power BI v2 changes not applied; exchanges with PM, GenAI, ML Engineering not recorded. Specialist explanation is partly resolved. Close: key takeaway, what I learned, what I would improve.')
tb(s, .6, 1.6, 6, 5, ['Limits', f'Facility and time views use {k["detailed_pct"]}% of appointments.', 'Model results are Data Science\'s; not recomputed.', 'Results very uniform: possible synthetic data.', 'No slot, bed-status or capacity data.'], 19, bul=True, head=True)
tb(s, 6.9, 1.6, 5.9, 5, ['Not finished', 'Attendance pattern analysis on a dataset (needs her appointment file).', 'Power BI v2 changes in Desktop.', 'Specialist structure check (H3).', 'Exchanges with PM, GenAI, ML Engineering.'], 19, bul=True, head=True)
prs.save(f'{OUT}/Presentation/Week8_Analytics_Presentation.pptx')
print('assets ok', len(prs.slides.__iter__.__self__._sldIdLst))
