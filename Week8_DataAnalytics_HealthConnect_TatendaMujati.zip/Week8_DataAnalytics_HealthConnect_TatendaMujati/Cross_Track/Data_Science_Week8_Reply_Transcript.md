# Data Science exchange, Week 8 final integration (Slack, 17 Nov 2026)

Evidence screenshots: `Evidence/Screenshots/W8_CrossTrack_01_my_final_outputs_to_DataScience.jpg` (my message, 10:36) and `W8_CrossTrack_02_DataScience_reply.jpg` (her reply; the screenshot shows the opening of the reply).

## My message to Shylet Nyazika (10:36) - verbatim from screenshot 01
Good day Shylet, for the Week 8 final integration, here are my final Data Analytics outputs

What I'm providing:
- Final KPIs, each recomputed independently and matched to SQL: 20,000 patients; 60,000 appointment IDs (only 5,000 with facility/department/date detail); billed RWF 9.31bn; collected 90.1%; outstanding RWF 919.9m; 42,036 claims, 49.98% approved, 21,028 pending (RWF 2.44bn); satisfaction 2.99/5 (40% poor); admission rate 8.33%.
- Validated findings: collection, claim approval and satisfaction are the same in every segment I tested, so segment variables (facility, department, visit type, gender, age, month) carry little signal in my data. Billing status and payment method are unreliable; 916 rows are dated after the extraction date but already have payments, so I'd avoid date logic on them.
- Attendance: not measurable in my files, so I'm presenting your model as the predictive component (accuracy 62.4% to [continues; remaining lines of the message are not visible in the screenshot]

## Reply from Shylet Nyazika (Data Science)
Opening, verbatim from screenshot 02:

> Hi Tatenda, thank you, this is really clear. Quick answers to your questions:
>
> Figures: yes, quote my model as accuracy 62.4% to 64.8% and ROC-AUC 0.677 to 0.687 (precision, recall and F1 are all 64.8%; Brier score 0.2246). My modelling used 5,000 appointment records, 4,737 after excluding cancelled ones, with 966 in the test set. I haven't verified your KPIs, so I'll cite them as yours.
>
> 1. What changed in how I documented the model:
> - Your finding that segment variables carry little signal matches my results. Gender, day, time and reminder channel add almost nothing to the model's predictions. It is driven by booking lead time, past no-show rate and distance to the clinic.
> - My model uses no billing, payment or claims fields, so your caution on those doesn't affect it. I haven't checked whether your 916 post-extraction rows overlap my appointment file, so I'll list that as a limitation.

Remainder of the reply (below the visible part of the screenshot), as pasted into the project chat and summarised here: a per-type table (test-set size, error and no-show rate for Diagnostic Test, Follow-up, General Consultation and Specialist Consultation; no-show rates 49.1% to 54.2% in every type; Specialist test n = 180, error 42.8%), a note that calibration is uneven at very low and very high scores, a final model summary, and the "can and cannot be used for" statement. To make this file fully verbatim, paste the complete Slack text over this paragraph.

## How this reply was used
See report Section 7 and Section 9, `Evidence/Week8_CrossTrack/crosstrack_checks.json`, and `Cross_Track/Week8_Integration_Record.md`.
Attribution: the per-type no-show rates come from Data Science's own table; Data Analytics' contribution is the negative segment finding, the three hypotheses, the consistency checks and the cautions on billing fields.
