# HC-POD handoff: validated analytics findings and data issues (Data Analytics, Week 7)

**From:** Tatenda Mujati (Data Analytics) **To:** Shylet Nyazika (Data Science); Project Management **Date:** 12 Nov 2026
Source: `Reports/Week7_Analytics_Testing_Refinement_Report.pdf`; evidence in `Evidence/test_register.csv` (test IDs in brackets).

## Validated findings you can rely on (held in every segment tested)
1. Collection rate is 90.1% of billed value, same across facility, department, visit type and month (C03).
2. Claim approval is about 50% for every insurer and bill-size quartile; 21,028 claims (RWF 2.44bn) are Pending (C04).
3. Average satisfaction is 2.99/5 and 40% of ratings are poor, in every segment (C01, C02).
4. No facility differs from the network average on satisfaction beyond sampling error (C07); do not rank facilities.
5. No significant monthly trend in poor ratings (C08).
6. 74.6% of patients have a chronic condition; stable across gender and age (C05).
7. Demand is flat across weekdays (D05).

## Data issues that affect your work
1. **No attendance / no-show field anywhere (D01); no valid proxy (D02, D04).** A no-show model cannot be trained on this data. Data Science confirmed (12 Nov) their appointment dataset has a no-show outcome; it is not in my files. Please share it, or per-type no-show counts.
2. **916 appointments dated after the 22 Oct 2026 extraction already have payments and diagnoses (D03).** Date-based features are unsafe.
3. **Three appointment counts** (60,000 IDs / 5,000 detailed / 60,809 monthly summary) (D06). Please agree one headline.
4. **Payment method is unrelated to insurance claims (E01).** Do not use it as a feature.
Also: only 5,000 of 60,000 appointments have facility, department, date or patient detail (B01-B09). Facility and time features exist for 8.3% of appointments.

## For Data Science
Segment variables (facility, department, visit type, gender, age group, month) show no significant association with satisfaction, collection or claim approval, so expect little signal from them.
## For Project Management
Please merge the 14 items in `Testing_Validation_Record.xlsx > Issue_Log` into the team Integration & Issue Log; items 6, 7, 8 and 9 need an owner outside Data Analytics.

## Reply received (12 Nov 2026, 08:36)
Tuned Gradient Boosting no-show model: accuracy 62.4% -> 64.8%, ROC-AUC 0.677 -> 0.687. Error by type: Diagnostic Test 31.2 -> 29.4%, Follow-up 38.7 -> 34.3%, General Consultation 36.5 -> 34.0%, Specialist Consultation 42.2 -> 42.8% (unexplained). Calibration uneven at very low and very high scores. Full text: `Data_Science_Reply_Transcript.md`.

## My answer on Specialist Consultation
- That type does not exist in my data (types: Consultation, Follow-up, Emergency), and visit type shows no difference in satisfaction, poor-rating share or collection (p = 0.68 / 0.32 / 0.99). My findings cannot explain it.
- Hypotheses to test on your data: H1 class balance (error is highest where the type's no-show rate is near 50%); H2 sample size (small group, noisy error); H3 structural difference (lead time, referral source, department or doctor mix).
- A +0.6 pt change is within noise (about 106,000 cases needed to confirm if before/after were independent samples), so "flat" is the right reading.
- Needed from you: no-show rate, case count and calibration table per appointment type, or the appointment file.

## Re-test after their change
[Pending: update when Data Science replies]
