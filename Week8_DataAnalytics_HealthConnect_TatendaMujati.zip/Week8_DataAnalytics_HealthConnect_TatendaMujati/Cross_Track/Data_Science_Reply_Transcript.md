# Data Science exchange (Slack, 12 Nov 2026) - transcript

Evidence screenshots: `Evidence/Screenshots/W7_CrossTrack_01_my_message_to_DataScience.jpg`, `W7_CrossTrack_02_DataScience_summary.jpg`.

**Shylet Nyazika (Data Science) 08:03:** Hi @Tatenda Mujati I'm from data science track please can we exchange our findings?
**Tatenda Mujati 08:27:** Hello @Shylet Nyazika, thank you so much for reaching out. Yes we can
**Shylet Nyazika 08:36:**
I'm on the Data Science track for HealthConnect. Here's a short summary of where my work stands:

Final output: a tested, tuned Gradient Boosting model that predicts appointment no-shows (64.8% accuracy, ROC-AUC 0.687, up from a 62.4% / 0.677 baseline).

Improved from Week 7: building on the Week 7 testing (overfitting and calibration checked, two suggested interaction features tested and rejected), I consolidated everything into final documentation, with a plain-language summary and a clear statement of what the model can and can't be used for.

Outstanding issue: Specialist Consultation still has the highest model error rate (about 42-43%) and I haven't found the cause. Calibration is also uneven at very low and very high scores.

What I need from you: any finding that explains why Specialist Consultation behaves differently, and your final KPI figures, so our numbers match in the walkthrough.

Here is my before/after:
* Model: accuracy went from 62.4% to 64.8%, and ROC-AUC from 0.677 to 0.687 (Week 5 baseline to the final tuned model).
* Lead time x prior no-show feature: accuracy 0.6480 to 0.6460 and AUC 0.6872 to 0.6864. It was slightly worse, so I rejected it.
* Specialist Consultation x lead time feature: no change in accuracy or AUC, and the model gave it zero importance, so I rejected it.
* Error by appointment type: tuning improved Diagnostic Test (31.2% to 29.4%), Follow-up (38.7% to 34.3%) and General Consultation (36.5% to 34.0%). Specialist Consultation stayed flat (42.2% to 42.8%).

**Tatenda Mujati 09:14:** I'm on the Data Analytics track, here are my validated analytics findings and final KPI figures. (Final KPIs, findings and modelling implications as in Cross_Track/HC-POD_Handoff_Note.md; the message is visible in screenshot 01.)
