# HC-POD final integration record: Data Analytics (Week 8)

The brief's 9 fields, for the exchange that actually took place (Data Analytics and Data Science). Evidence: `Evidence/Screenshots/` (W7 x2, W8 x2), `Cross_Track/Data_Science_Reply_Transcript.md`, `Cross_Track/Data_Science_Week8_Reply_Transcript.md`, `Evidence/Week8_CrossTrack/`.

| # | Field | Record |
|---|---|---|
| 1 | Track collaborated with | Data Science (Shylet Nyazika), Slack, 12 Nov and 17 Nov 2026 |
| 2 | Dependency | Data Science needs validated analytics findings and KPIs for model interpretation and a matching walkthrough. Data Analytics needs the no-show outcome (absent from my Week 6 files). |
| 3 | Output received | 12 Nov: model summary (62.4% to 64.8%, ROC-AUC 0.677 to 0.687), per-type error, two rejected features. 17 Nov reply: precision/recall/F1 64.8%, Brier 0.2246, 5,000 records (4,737 after cancelled; 966 test), drivers (lead time, past no-show, distance), per-type no-show rates 49.1-54.2%, calibration, documentation changes, KPIs cited as mine |
| 4 | Output provided | Final KPIs, five segment-validated findings, modelling cautions, three hypotheses (class balance, sample size, structure) and a data request |
| 5 | Final integration activity | Sent final KPIs 17 Nov 10:36; checked her figures for consistency (record counts and weighted error reconcile); H1 class balance rejected; H2 sample size suggestive (z = 2.37, p = 0.018, 0.07 after Bonferroni); H3 structure open; agreed which figures are cited as whose |
| 6 | What changed | Her documentation now states segment variables add almost nothing and that her model uses no billing, payment or claims fields. Overlap of my 916 post-extraction rows with her appointment file is listed by her as a limitation. Model unchanged. |
| 7 | How the change improved the solution | Narrowed the Specialist error to sample size and booking structure; kept both sides' numbers clearly attributed; gave the model team data cautions |
| 8 | Evidence | Four Slack screenshots, two transcripts, Week 7 tests X01-X04, Week 8 checks (Evidence/Week8_CrossTrack), handoff note, follow-up message |
| 9 | Contribution to the final presentation | Analytics section: findings, KPIs, recommendations, and how analytics informs and limits the model. Data Science presents the model. |

## Status of the other final-integration flows (from the brief's matrix)
| Flow | Status |
|---|---|
| Data Analytics to Data Science | Done (evidenced, both exchanges). Specialist structure check (H3) open. |
| Data Analytics to Project Management | Outputs prepared (handoff note, issue log of 15 items). Exchange not yet recorded. |
| Data Analytics to GenAI | Suggestion prepared (Recommendation 6). Not yet shared. |
| Data Analytics to ML Engineering | Data-quality constraints prepared. Not yet shared. |
| Data Science to Data Analytics | Done for results (17 Nov). Appointment file not received. |

Update the last column of this table when replies arrive. Do not mark a flow as done without evidence.
