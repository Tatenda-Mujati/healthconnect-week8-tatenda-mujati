Hi Shylet, thanks for your summary. I've checked it against my Week 6 data and findings.

Specialist Consultation: that type doesn't exist in my files (mine are Consultation, Follow-up, Emergency), and visit type shows no difference in my data (satisfaction p = 0.68, poor-rating share p = 0.32, collection p = 0.99), so I can't explain the 42-43% error from my side. Three things I'd test on yours:
1. Class balance: if Specialist's no-show rate is close to 50%, its error is mechanically higher at the same signal strength. Could you send the no-show rate by appointment type?
2. Sample size: a +0.6 pt change (42.2 to 42.8%) is within noise unless the group has about 100,000 cases, so "flat" is the right reading. How many Specialist cases are in your test set?
3. Structure: does Specialist differ in lead time, referral source, department or doctor mix? Slicing the errors by those might show where they concentrate.
If you can share the appointment file (or the per-type no-show rate, case count and calibration table), I'll run the KPI set and these checks on it so our numbers match.

Your reported figures are internally consistent (64.8% / 0.687 match your feature-test baseline; overall error 35.2% sits inside the per-type range).
